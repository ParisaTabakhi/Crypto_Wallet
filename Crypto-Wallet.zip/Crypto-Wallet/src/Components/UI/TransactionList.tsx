import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { Transaction, WalletContext } from '../../Context/Context';


interface WalletUIProps {
    increaseBalance: () => void; 
}
const WalletUI: React.FC<WalletUIProps> = ({ increaseBalance }) => {
    const walletContext = useContext(WalletContext);
    
    return (
        <div className="bg-blue-100 p-5 rounded-lg shadow-md flex flex-col items-center justify-center ">
            <h3 className="text-2xl text-blue-700 font-bold mb-5">Balance: {walletContext.balance}</h3>
            <div className="mb-4">
                <Link to='/receive' className="bg-blue-400 text-white px-4 py-2 rounded hover:bg-blue-500 transition mr-4">Receive</Link>
                <Link to='/send' className="bg-blue-400 text-white px-4 py-2 rounded hover:bg-blue-500 transition mr-4">Send</Link>
            </div>
            <button 
                onClick={increaseBalance} 
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                Increase
            </button>
            <div className="mt-5">
                {walletContext.transactions.map((item: Transaction, index: number) => (
                    <div key={index} className="bg-white p-4 rounded-lg shadow mb-4">
                        <p className="text-blue-600 font-semibold">Amount: {item.amount}</p>
                        {item.crypto_currency_symbol && (
                            <p className="text-gray-600">Crypto Currency: {item.crypto_currency_symbol}</p>
                        )}
                        <p className="text-gray-500">Transaction Date: {item.transaction_date}</p>
                        {item.address && (
                            <p className="text-gray-600">Wallet Address: {item.address}</p>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
}

export default WalletUI;
