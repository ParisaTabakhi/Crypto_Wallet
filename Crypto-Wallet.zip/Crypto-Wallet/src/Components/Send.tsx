
import React, { useContext, useState } from 'react';
import { WalletContext } from '../Context/Context';
import WalletForm from './UI/Send';

const Send: React.FC = () => {
    const walletContext = useContext(WalletContext);
    const [error, setError] = useState<string>('');

    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        
        const amount = parseFloat(walletContext.formData.amount);
        const balance = walletContext.balance;

        if (amount <= balance) {
            const newTransaction = {
                ...walletContext.formData,
                transaction_date: new Date().toISOString(), 
            };
            walletContext.addTransaction(newTransaction);
            walletContext.setBalance(balance - amount);
            setError(''); 
        } else {
            setError('Not enough stock');
        }
    
    }
    
    return (
        <WalletForm handleSubmit={handleSubmit} error={error} />
    );
}

export default Send;
