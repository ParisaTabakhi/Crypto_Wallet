
import React, { useState } from 'react';
import { generate } from 'random-words';
import GenerateWordsUI from './UI/GenerateWords';

const GenerateWords: React.FC<{ onWordsGenerated: (words: string[]) => void }> = ({ onWordsGenerated }) => {
    const [words, setWords] = useState<string[]>([]);
    const [error , setError] = useState('')
    const handleGenerateWords = () => {
        const randomWordsArray = generate(12);
        if (Array.isArray(randomWordsArray) && randomWordsArray.length > 0) {
            setWords(randomWordsArray);
            onWordsGenerated(randomWordsArray);
            setError(''); 
        } else {
            setError('Failed to generate words')
        }
    };

    return (
        <GenerateWordsUI onGenerate={handleGenerateWords} error={error} />
    );
};

export default GenerateWords;
