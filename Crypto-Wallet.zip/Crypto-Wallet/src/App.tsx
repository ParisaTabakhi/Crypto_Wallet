import React from 'react'; 
import './index.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import CreateWallet from './Components/CreateWallet';
import Send from './Components/Send';
import { WalletProvider } from './Context/Context';
import Receive from './Components/Receive';
import MainWallet from './Components/TransactionList'

const App: React.FC = () => {
  return (
    <>
      <WalletProvider>
        <BrowserRouter>
          <Routes>
            <Route path='/' element={<CreateWallet />} />
            <Route path='send' element={<Send />} />
            <Route path='receive' element={<Receive />} />
            <Route path='Wallet' element={<MainWallet />} />
          </Routes>
        </BrowserRouter>
      </WalletProvider>
    </>
  );
}

export default App;
