import React, { useCallback, useContext, useEffect , useState } from 'react';
import { WalletContext } from '../Context/Context';
import WalletUI from '../Components/UI/TransactionList'


interface Data {
    id: number;
    amount: number;
    crypto_currency_symbol: string;
    transaction_date : string ;
  }
const Wallet: React.FC = () => {
    const walletContext = useContext(WalletContext);
    const [data, setData] = useState<Data[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    
    useEffect(() => {
        const storedBalance = localStorage.getItem('balance');
        if (storedBalance) {
            walletContext.setBalance(Number(storedBalance));
        }
    }, []);
    
    useEffect(() => {
        localStorage.setItem('balance', walletContext.balance.toString());
    }, [walletContext.balance]);

    const increaseBalance = useCallback(() => {
        walletContext.setBalance(prevBalance => prevBalance + 1);
    }, [walletContext.setBalance]);

  
    
  
    useEffect(() => {
      const fetchData = async () => {
          try {
              const response = await fetch('/data.json'); 
              if (!response.ok) {
                  throw new Error('Network response was not ok');
              }
              const jsonData: Data[] = await response.json();
              setData(jsonData);
          } catch (error) {
              setError(error.message);
          } finally {
              setLoading(false);
          }
      };

      fetchData();
  }, []);
    if (loading) {
      return <p className='flex flex-col items-center  text-blue-500 font-bold pt-5'>Loading...</p>;
    }
  
    if (error) {
      return <p className='flex flex-col items-center  text-red-500 font-bold pt-5 '>Error: {error}</p>;
    }

    return (
       <>
         <WalletUI increaseBalance={increaseBalance}
          data={data}
         />
       </>
    );
}

export default Wallet;
