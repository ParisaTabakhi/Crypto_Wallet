import React from 'react';

interface GenerateWordsUIProps {
    onGenerate: () => void;
    error: string | null;
}

const GenerateWordsUI: React.FC<GenerateWordsUIProps> = ({ onGenerate, error }) => {
    return (
        <>
            <button 
                className='bg-blue-500 text-white font-bold py-2 px-4 rounded hover:bg-blue-600' 
                onClick={onGenerate}>
                Generate Words
            </button>
            {error && <p className='text-red-500 mt-2 text-center'>{error}</p>}
        </>
    );
};

export default GenerateWordsUI;
