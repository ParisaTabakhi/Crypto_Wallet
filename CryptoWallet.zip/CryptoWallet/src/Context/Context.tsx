import React, { createContext, useState, useEffect } from 'react';

export interface Transaction {
    amount: number;
    crypto_currency_symbol?: string;
    transaction_date: string;
    address?: string;
}
interface WalletContextType {
    uuid: string;
    setUuid: React.Dispatch<React.SetStateAction<string>>;
    balance: number;
    setBalance: React.Dispatch<React.SetStateAction<number>>;
    formData: { address: string; amount: string; };
    setFormData: React.Dispatch<React.SetStateAction<{ address: string; amount: string; }>>;
    transactions: Transaction[];
    setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
    addTransaction: (transaction: any) => void;
}

export const WalletContext = createContext<WalletContextType>({} as WalletContextType);

export const WalletProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const initialState = { address: '', amount: '' };
    
    const [formData, setFormData] = useState(initialState);
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [uuid, setUuid] = useState(() => localStorage.getItem('uuid') || '');
    const [balance, setBalance] = useState(() => {
        const storedBalance = localStorage.getItem('balance');
        return storedBalance ? Number(storedBalance) : 0;
    });

   
    const addTransaction = (transaction: Transaction) => {
        const updatedTransactions = [...transactions, transaction];
        setTransactions(updatedTransactions);
        localStorage.setItem('transactions', JSON.stringify(updatedTransactions)); 
    };

    useEffect(() => {
        const storedTransactions = localStorage.getItem('transactions');
        if (storedTransactions) {
            setTransactions(JSON.parse(storedTransactions));
        }
    }, []);

    useEffect(() => {
        localStorage.setItem('uuid', uuid);
    }, [uuid]);

    return (
        <WalletContext.Provider value={{ uuid, setUuid, balance, setBalance, formData, setFormData, transactions, setTransactions, addTransaction  }}>
            {children}
        </WalletContext.Provider>
    );
}
